<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pegawai_m extends CI_Model
{
    public function view()
    {
        return $this->db->get('pegawai')->result();
    }

    //fungsi untuk upload data
    public function upload_file($filename)
    {
        $this->load->library('upload');
        $config['upload_path'] = './assets/excel/';
        $config['allowed_types'] = 'xlsx';
        $config['max_size']  = '2048';
        $config['overwrite'] = true;
        $config['file_name'] = $filename;

        $this->upload->initialize($config); // Load konfigurasi uploadnya
        if ($this->upload->do_upload('file')) {
            $return = array('result' => 'success', 'file' => $this->upload->data(), 'error' => '');
            return $return;
        } else {
            $return = array('result' => 'failed', 'file' => '', 'error' => $this->upload->display_errors());
            return $return;
        }
    }

    public function insert_multiple($data)
    {
        $this->db->insert_batch('pegawai', $data);
    }
}

/* End of file Pegawai_m.php */
