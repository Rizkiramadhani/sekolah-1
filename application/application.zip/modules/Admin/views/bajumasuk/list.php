<?php
$ctrl = $this->uri->segment(1) . '/' . $this->uri->segment(2);
?>
<div class="row">
    <div class="col-12">
        <a href="<?= base_url($ctrl . '/add') ?>" class="btn btn-success">Tambah Data</a>
    </div>
</div>
<br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="basic-datatable" class="table dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Aksi</th>
                            <th>No</th>
                            <th>Id Baju</th>
                            <th>Nama Baju</th>
                            <th>Lengan Panjang</th>
                            <th>Tanggal Masuk</th>
                            <th>Jumlah (Pcs)</th>
                            <th>Total Harga Beli</th>
                            <th>Ukuran</th>
                            <th>Harga(Pcs)</th>
                            <th>Warna</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = '1'; ?>
                        <?php foreach ($data as $row) : ?>
                            <tr>
                                <td align="center" width="100">
                                    <div class="btn-group dropdown">
                                        <a href="javascript: void(0);" class="dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="<?= base_url($ctrl . '/edit/' . $row->idBaju) ?>"><i class="mdi mdi-pencil mr-1 text-muted"></i>Edit</a>
                                            <a class="dropdown-item hapus" href="<?= base_url($ctrl . '/delete/' . $row->idBaju) ?>"><i class="mdi mdi-delete mr-1 text-muted"></i>Hapus</a>
                                            <!-- <a class="dropdown-item" href="#"><i class="mdi mdi-email mr-1 text-muted"></i>Send Email</a> -->
                                        </div>
                                    </div>
                                </td>
                                <td><?= $no++ ?></td>
                                <td><?= $row->idBaju ?></td>
                                <td><?= $row->namaBaju ?></td>
                                <td align="center"><?= $row->lenganPanjang ?></td>
                                <td align="center"><?= $row->tanggalMasuk ?></td>
                                <td align="right"><?= $row->stok ?></td>
                                <td align="right">Rp. <?= number_format(floatval($row->harga), 0, ',', '.') ?></td>
                                <td><?= $row->ukuran ?></td>
                                <td align="right">Rp. <?= number_format(floatval($row->hargaBaju), 0, ',', '.') ?></td>
                                <td><?= $row->warna ?></td>
                                <td>
                                    <?php if (empty($row->fotoBaju)) : ?>
                                        Foto Baju Tidak Ada !
                                    <?php else : ?>
                                        <img src="<?= base_url('upload/' . $row->fotoBaju) ?>" alt="">
                                    <?php endif ?>
                                </td>

                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>

            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>