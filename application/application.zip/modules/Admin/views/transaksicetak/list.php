<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body ribbon-box">
                <div class="ribbon ribbon-danger">No Transaksi :<?= date('Y') ?><?= $otomatis ?> </div>
                <br>
                <br>
                <br>
                <form class="needs-validation" novalidate="" id="form-data" action="<?= base_url('admin/transaksicetak/kasir_barangAction') ?>" method="post">
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Jenis Cetak</label>
                        <input type="text" class="form-control" name="jenisCetak" class="form-control" required="">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Bahan</label>
                        <input type="text" class="form-control" name="noTransaksi" value="<?= $otomatis ?>" id="validationCustom01" hidden required="">
                        <?= cmb_dinamis('idBahanBaku', 'bahanBaku', 'namaBahanBaku', 'idBahanBaku', '', 'class="form-control" id="idBahan" onChange="baju()"') ?>
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Harga Satuan Bahan</label>
                        <input type="text" class="form-control" name="hargaBahan" id="hargaBahan" class="form-control" required="">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Jumlah</label>
                        <input type="text" class="form-control" name="jumlah" id="" class="form-control" required="">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Ongkos</label>
                        <input type="text" class="form-control" name="ongkos" id="" class="form-control" required="">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Simpan</button>
                </form>
                <br>
                <br>
                <div id="data">

                </div>
                <form class="needs-validation" novalidate="" id="form-data" action="<?= base_url('admin/transaksiBaju/kasir_Action') ?>" method="post">
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Total Harga</label>
                        <input type="text" class="form-control" name="th" id="th" required="" data-toggle="input-mask" data-mask-format="#.##0" data-reverse="true">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <div class="form-group mb-2">
                        <label for="validationCustom01">Total Bayar</label>
                        <input type="text" class="form-control" name="tb" id="tb" required="" data-toggle="input-mask" data-mask-format="#.##0" data-reverse="true">
                        <div class="invalid-feedback">
                            Harus di isi.
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Simpan</button>
                    <!-- <a href="<?= base_url('laporan/nota') ?>" target="_blank" class="btn btn-warning">Cetak Nota</a> -->
                </form>
            </div> <!-- end card-body-->

        </div>
    </div>
</div>
<script>
    function showHarga() {
        var no = '<?= $this->session->userdata("auto") ?>';
        $.ajax({
            type: 'GET',
            url: '<?= base_url("admin/transaksiCetak/ajaxHarga") ?>',
            data: "no=" + no,
            success: function(data) {
                var json = data,
                    obj = JSON.parse(json);
                $('#th').val(obj.th);
                $('#tb').val(obj.th);
            }
        })
    }

    function baju() {
        var idBahan = $("#idBahan").val();
        $.ajax({
            url: '<?= base_url("admin/transaksicetak/ajaxbahan") ?>',
            data: "idBahan=" + idBahan,
            success: function(data) {
                var json = data,
                    obj = JSON.parse(json);
                $('#hargaBahan').val(obj.hargaBahan);
            }
        })
    }

    function resetForm() {
        $('[name=jumlah]').val('');
        $('[name=jumlah]').focus();
    }

    function loadData() {
        $.get("<?= base_url('admin/transaksicetak/dataBajuKeluar') ?>", function(data) {
            $('#data').html(data)
        });

    }
</script>