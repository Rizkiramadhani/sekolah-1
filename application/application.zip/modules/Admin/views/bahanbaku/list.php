<?php
$ctrl = $this->uri->segment(1) . '/' . $this->uri->segment(2);
?>
<div class="row">
    <div class="col-12">
        <a href="<?= base_url($ctrl . '/add') ?>" class="btn btn-success">Tambah Data</a>
    </div>
</div>
<br>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="basic-datatable" class="table dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Aksi</th>
                            <th>No</th>
                            <th>Id Bahan Baku</th>
                            <th>Nama Bahan Baku</th>
                            <th>Tanggal Masuk</th>
                            <th>Jumlah (Pcs)</th>
                            <th>Total Harga Beli</th>
                            <th>Harga Jual(Pcs)</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = '1'; ?>
                        <?php foreach ($data as $row) : ?>
                            <tr>
                                <td align="center" width="100">
                                    <div class="btn-group dropdown">
                                        <a href="javascript: void(0);" class="dropdown-toggle arrow-none btn btn-light btn-sm" data-toggle="dropdown" aria-expanded="false"><i class="mdi mdi-dots-horizontal"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="<?= base_url($ctrl . '/edit/' . $row->idBahanBakuMasuk) ?>"><i class="mdi mdi-pencil mr-1 text-muted"></i>Edit</a>
                                            <a class="dropdown-item hapus" href="<?= base_url($ctrl . '/delete/' . $row->idBahanBakuMasuk) ?>"><i class="mdi mdi-delete mr-1 text-muted"></i>Hapus</a>
                                            <!-- <a class="dropdown-item" href="#"><i class="mdi mdi-email mr-1 text-muted"></i>Send Email</a> -->
                                        </div>
                                    </div>
                                </td>
                                <td><?= $no++ ?></td>
                                <td><?= $row->idBahanBaku ?></td>
                                <td><?= $row->namaBahanBaku ?></td>
                                <td align="center"><?= $row->tanggalMasuk ?></td>
                                <td align="right"><?= $row->jumlah ?></td>
                                <td align="right">Rp. <?= number_format(floatval($row->hargaBeli), 0, ',', '.') ?></td>
                                <td align="right">Rp. <?= number_format(floatval($row->hargaJual), 0, ',', '.') ?></td>
                                <td>
                                    <?php if (empty($row->fotoBahanBaku)) : ?>
                                        Foto Baju Tidak Ada !
                                    <?php else : ?>
                                        <img src="<?= base_url('upload/' . $row->fotoBahanBaku) ?>" alt="">
                                    <?php endif ?>
                                </td>

                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>

            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>