<?php
$ctrl = $this->uri->segment(1) . '/' . $this->uri->segment(2);
?>
<div class="card">
    <div class="card-body">
        <form class="needs-validation" novalidate="" action="<?= base_url($ctrl . '/addAction') ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label>Tanggal Masuk</label>
                <input type="text" name="tanggalMasuk" class="form-control date" id="birthdatepicker" data-toggle="date-picker" data-single-date-picker="true">
            </div>
            <div class="form-group mb-3">
                <label for="validationCustom01">Bahan Baku</label>
                <select name="idBahanBaku" class="form-control">
                    <?php foreach ($bahanBaku as $data) : ?>
                        <option value="<?= $data->idBahanBaku ?>"><?= $data->namaBahanBaku ?></option>
                    <?php endforeach ?>
                </select>
                <div class="invalid-feedback">
                    Harus di isi.
                </div>
            </div>
            <div class="form-group mb-3">
                <label for="validationCustom01">Jumlah</label>
                <input type="text" name="jumlah" id="validationCustom01" class="form-control" required="" data-toggle="input-mask" data-mask-format="#.##0" data-reverse="true">
                <div class="invalid-feedback">
                    Harus di isi.
                </div>
            </div>
            <div class="form-group mb-3">
                <label for="validationCustom01">Total Harga Beli</label>
                <input type="text" name="hargaBeli" id="validationCustom01" class="form-control" required="" data-toggle="input-mask" data-mask-format="#.##0" data-reverse="true">
                <div class="invalid-feedback">
                    Harus di isi.
                </div>
            </div>
            <button class="btn btn-primary" type="submit">Simpan</button>
            <a href="<?= base_url($ctrl) ?>" class="btn btn-danger">Kembali</a>
        </form>

    </div> <!-- end card-body-->
</div>
<script>
    function showBaju() {
        var lengan = $("#lengan").val();
        $.ajax({
            type: 'GET',
            url: '<?= base_url("admin/bajumasuk/ajaxbm") ?>',
            data: "lengan=" + lengan,
            success: function(data) {
                $('#data').html(data)
            }
        })

    }
</script>