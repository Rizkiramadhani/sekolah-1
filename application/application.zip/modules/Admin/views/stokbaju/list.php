<?php
$ctrl = $this->uri->segment(1) . '/' . $this->uri->segment(2);
?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="basic-datatable" class="table dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Id Baju</th>
                            <th>Nama Baju</th>
                            <th>Lengan Panjang</th>
                            <th>Jumlah (Pcs)</th>
                            <th>Ukuran</th>
                            <th>Harga(Pcs)</th>
                            <th>Warna</th>
                            <th>Foto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = '1'; ?>
                        <?php foreach ($data as $row) : ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $row->idBaju ?></td>
                                <td><?= $row->namaBaju ?></td>
                                <td align="center"><?= $row->lenganPanjang ?></td>
                                <td align="right"><?= $row->stok ?></td>
                                <td><?= $row->ukuran ?></td>
                                <td align="right">Rp. <?= number_format(floatval($row->hargaBaju), 0, ',', '.') ?></td>
                                <td><?= $row->warna ?></td>
                                <td>
                                    <?php if (empty($row->fotoBaju)) : ?>
                                        Foto Baju Tidak Ada !
                                    <?php else : ?>
                                        <img src="<?= base_url('upload/' . $row->fotoBaju) ?>" alt="">
                                    <?php endif ?>
                                </td>

                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>

            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div><!-- end col-->
</div>