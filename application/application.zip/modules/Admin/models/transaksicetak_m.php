<?php

defined('BASEPATH') or exit('No direct script access allowed');

class transaksicetak_m extends CI_Model
{

    function bahanBakuKeluar()
    {
        $o = $this->input->post('ongkos');
        $hb = $this->input->post('hargaBahan');
        $jum = $this->input->post('jumlah');
        $thb = $hb * $jum;
        $th = $thb + $o;
        $object = [
            'tanggalKeluar' => date('Y-m-d'),
            'noTransaksi' => $this->input->post('noTransaksi'),
            'idBahanBaku' => $this->input->post('idBahanBaku'),
            'jumlah' => $jum,
            'totalHarga' => $th,
            'ongkos' => $o,
            'jenisCetak' => $this->input->post('jenisCetak'),

        ];
        $this->db->insert('bahanbakukeluar', $object);
    }

    function subTransaksi()
    {
        $object = [
            'noTransaksi' => $this->session->userdata('auto'),
            'tahun' => date('Y'),
            'tanggalTransaksi' => date('Y-m-d'),
            'th' => $this->input->post('th'),
            'tb' => $this->input->post('tb'),
        ];
        $this->db->insert('transaksi', $object);
    }
}

/* End of file */
