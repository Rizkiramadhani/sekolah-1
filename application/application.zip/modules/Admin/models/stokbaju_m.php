<?php

defined('BASEPATH') or exit('No direct script access allowed');

class stokbaju_m extends CI_Model
{

    public $namaTable = 'stokbaju';
    // public $pk = 'idBajuMasuk';

    function getAllData()
    {
        $this->db->join('baju', 'baju.idBaju = stokbaju.idBaju', 'left');
        return $this->db->get($this->namaTable)->result();
    }
}

/* End of file */
