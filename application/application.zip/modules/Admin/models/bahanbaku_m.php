<?php

defined('BASEPATH') or exit('No direct script access allowed');

class bahanbaku_m extends CI_Model
{

    public $namaTable = 'bahanbakumasuk';
    public $pk = 'idBahanBakuMasuk';

    function getAllData()
    {
        $this->db->order_by('tanggalMasuk', 'desc');

        $this->db->join('bahanbaku', 'bahanbaku.idBahanBaku = bahanbakumasuk.idBahanBaku', 'left');

        return $this->db->get($this->namaTable)->result();
    }

    function getDataById($Value)
    {
        $this->db->where($this->pk, $Value);
        $this->db->join('bahanbaku', 'bahanbaku.idBahanBaku = bahanbakumasuk.idBahanBaku', 'left');
        return $this->db->get($this->namaTable)->row();
    }

    function bahanbaku()
    {
        $this->db->where('ket', '0');
        $this->db->join('kategori', 'kategori.idKategori = bahanBaku.idKategori', 'left');

        return $this->db->get('bahanbaku')->result();
    }

    function save()
    {
        $tgl = date('Y-m-d', strtotime($this->input->post('tanggalMasuk')));
        $object = [
            'idBahanBaku' => $this->input->post('idBahanBaku'),
            'tanggalMasuk' => $tgl,
            'jumlah' => str_replace('.', '', $this->input->post('jumlah')),
            'hargaBeli' => str_replace('.', '', $this->input->post('hargaBeli')),
        ];
        $this->db->insert($this->namaTable, $object);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Disimpan</div>');
    }

    function update($Value)
    {
        $tgl = date('Y-m-d', strtotime($this->input->post('tanggalMasuk')));
        $object = [
            'idBahanBaku' => $this->input->post('idBahanBaku'),
            'tanggalMasuk' => $tgl,
            'jumlah' => str_replace('.', '', $this->input->post('jumlah')),
            'hargaBeli' => str_replace('.', '', $this->input->post('hargaBeli')),
        ];

        $this->db->where($this->pk, $Value);
        $this->db->update($this->namaTable, $object);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Di Rubah</div>');
    }

    function delete($Value)
    {
        $this->db->where($this->pk, $Value);
        $this->db->delete($this->namaTable);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Di Hapus</div>');
    }
}

/* End of file */
