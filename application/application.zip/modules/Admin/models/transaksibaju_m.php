<?php

defined('BASEPATH') or exit('No direct script access allowed');

class transaksibaju_m extends CI_Model
{

    function bajuKeluar()
    {
        $ios = $this->input->post('idOngkosSablon');
        $hb = $this->input->post('harga');
        $this->db->where('idOngkosSablon', $ios);
        $os = $this->db->get('ongkossablon')->row();
        $hs = $os->hargaSablon;

        $jum = $this->input->post('jumlah');
        $thb = $hb * $jum;
        $ths = $hs * $jum;
        $th = $thb + $ths;

        $object = [
            'tanggalBajuKeluar' => date('Y-m-d'),
            'noTransaksi' => $this->input->post('noTransaksi'),
            'idBaju' => $this->input->post('idBaju'),
            'jumlah' => $jum,
            'idOngkosSablon' => $ios,
            'totalHarga' => $th,
        ];
        $this->db->insert('bajukeluar', $object);
    }

    function subTransaksi()
    {
        $object = [
            'noTransaksi' => $this->session->userdata('auto'),
            'tahun' => date('Y'),
            'tanggalTransaksi' => date('Y-m-d'),
            'th' => $this->input->post('th'),
            'tb' => $this->input->post('tb'),
        ];
        $this->db->insert('transaksi', $object);
    }
}

/* End of file */
