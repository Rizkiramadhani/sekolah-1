<?php

defined('BASEPATH') or exit('No direct script access allowed');

class stokbahanbaku_m extends CI_Model
{

    public $namaTable = 'stokbahanbaku';
    // public $pk = 'idBajuMasuk';

    function getAllData()
    {
        $this->db->join('bahanbaku', 'bahanbaku.idBahanBaku = stokbahanbaku.idBahanBaku', 'left');
        return $this->db->get($this->namaTable)->result();
    }
}

/* End of file */
