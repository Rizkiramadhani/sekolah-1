<?php


defined('BASEPATH') or exit('No direct script access allowed');

class bahanbaku extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('bahanbaku_m');
    }
    public $titles = 'Bahan Baku Masuk';
    public $vn = 'bahanbaku';

    public function index()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Data " . $this->titles;
        $data['data'] = $this->bahanbaku_m->getAllData();

        $this->template->load('template', $this->vn . '/list', $data);
    }

    function add()
    {
        $data['bahanBaku'] = $this->bahanbaku_m->bahanbaku();
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $this->template->load('template', $this->vn . '/add', $data);
    }

    function addAction()
    {
        $this->bahanbaku_m->save();
        redirect('admin/' . $this->vn);
    }

    function edit()
    {
        $data['bahanBaku'] = $this->bahanbaku_m->bahanbaku();
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $id = $this->uri->segment(4);
        $data['row'] = $this->bahanbaku_m->getDataById($id);
        $this->template->load('template', $this->vn . '/edit', $data);
    }

    function editAction()
    {
        $id = $this->uri->segment(4);
        $this->bahanbaku_m->update($id);
        redirect('admin/' . $this->vn);
    }

    function delete()
    {
        $id = $this->uri->segment(4);
        $this->bahanbaku_m->delete($id);
        redirect('admin/' . $this->vn);
    }
}

/* End of file Rt.php */
