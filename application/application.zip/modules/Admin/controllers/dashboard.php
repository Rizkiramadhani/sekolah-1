<?php

defined('BASEPATH') or exit('No direct script access allowed');

class dashboard extends CI_Controller
{

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['pageTitle'] = 'Dashboard';
        $this->template->load('template', 'admin/dashboard/dash', $data);
    }
}

/* End of file dashboard.php */
