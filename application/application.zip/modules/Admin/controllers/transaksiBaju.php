<?php


defined('BASEPATH') or exit('No direct script access allowed');

class transaksiBaju extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('transaksibaju_m');
    }
    public $titles = 'Transaksi Sablon Baju';
    public $vn = 'transaksiBaju';

    public function index()
    {
        $sql = "SELECT max(noTransaksi) as no FROM transaksi";
        $result = $this->db->query($sql)->row();
        if ($result) {
            $a = $result->no;
            $nilai = substr($a, '1');
            $kd = (int) $nilai;
            $kd = $kd + '1';
            $hasil = str_pad($kd, 4, "0", STR_PAD_LEFT);
        } else {
            $hasil = "0001";
        }
        $data['otomatis'] = $hasil;
        $array = array(
            'auto' => $hasil
        );
        $this->session->set_userdata($array);
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $this->template->load('template', $this->vn . '/list', $data);
    }

    function kasir_barangAction()
    {
        $this->transaksibaju_m->bajuKeluar();
    }

    function kasir_Action()
    {
        $this->transaksibaju_m->subTransaksi();
        redirect('admin/transaksiBaju');
    }

    function dataBajuKeluar()
    {
        $this->db->where('noTransaksi', $this->session->userdata('auto'));
        $this->db->join('baju', 'baju.idBaju = bajukeluar.idBaju', 'left');
        $this->db->join('ongkossablon', 'ongkossablon.idOngkosSablon = bajuKeluar.idOngkosSablon');
        $keluar = $this->db->get('bajukeluar')->result();
        echo '<div class="table-responsive mt-3">
        <table class="table table-hover table-centered mb-0">';
        echo '<thead>
        <tr>
            <th>Nama Baju</th>
            <th>Ukuran</th>
            <th>Warna</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Warna Sablon</th>
            <th>Total Harga</th>
            <th></th>
        </tr>
    </thead>';
        echo '<tbody>';
        foreach ($keluar as $row) :
            echo    '<tr>
            <td>' . $row->namaBaju . '</td>
            <td>' . $row->ukuran . '</td>
            <td>' . $row->warna . '</td>
            <td>' . $row->jumlah . '</td>
            <td>' . number_format(floatval($row->hargaBaju), 0, ',', '.') . '</td>
            <td>' . $row->jumlahWarna . ' Warna</td>
            <td>' . number_format(floatval($row->totalHarga), 0, ',', '.') . '</td>
            <td><a class=" hapus" href=" ' . base_url('admin/transaksibaju/ajaxdelete/' . $row->idBajuKeluar) . '"><i class="mdi mdi-delete mr-1 text-muted"></i>Hapus</a></td>
            </tr>';
        endforeach;
        echo '</tbody>';
        echo '</table>
        </div>';
    }

    function ajaxharga()
    {
        if (isset($_GET['no'])) {
            $no = $_GET['no'];
            $this->db->select_sum('totalHarga', 'total');
            $this->db->where('noTransaksi', $no);
            $hasil = $this->db->get('bajuKeluar')->row();
            $data = [
                'th' => $hasil->total
            ];
            echo json_encode($data);
        }
    }

    function ajaxBaju()
    {
        $idBaju = $_GET['idBaju'];
        $this->db->where('idBaju', $idBaju);
        $row = $this->db->get('baju')->row_array();

        $data = [
            'harga' => $row['hargaBaju'],
            'ukuran' => $row['ukuran'],
            'warna' => $row['warna'],
            'lenganPanjang' => $row['lenganPanjang']
        ];
        echo json_encode($data);
    }

    function ajaxdelete()
    {
        $id = $this->uri->segment(4);
        $this->db->where('idBajuKeluar', $id);
        $this->db->delete('bajukeluar');
        redirect('admin/' . $this->vn);
    }
}

/* End of file Rt.php */
