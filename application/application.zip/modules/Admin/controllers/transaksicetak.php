<?php


defined('BASEPATH') or exit('No direct script access allowed');

class transaksicetak extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('transaksicetak_m');
    }
    public $titles = 'Transaksi Cetak';
    public $vn = 'transaksicetak';

    public function index()
    {
        $sql = "SELECT max(noTransaksi) as no FROM transaksi";
        $result = $this->db->query($sql)->row();
        if ($result) {
            $a = $result->no;
            $nilai = substr($a, '1');
            $kd = (int) $nilai;
            $kd = $kd + '1';
            $hasil = str_pad($kd, 4, "0", STR_PAD_LEFT);
        } else {
            $hasil = "0001";
        }
        $data['otomatis'] = $hasil;
        $array = array(
            'auto' => $hasil
        );
        $this->session->set_userdata($array);
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $this->template->load('template', $this->vn . '/list', $data);
    }

    function kasir_barangAction()
    {
        $this->transaksicetak_m->bahanBakuKeluar();
    }

    function kasir_Action()
    {
        $this->transaksibaju_m->subTransaksi();
        redirect('admin/transaksiBaju');
    }

    function dataBajuKeluar()
    {
        $this->db->where('noTransaksi', $this->session->userdata('auto'));
        $this->db->join('bahanbaku', 'bahanbaku.idBahanBaku = bahanbakukeluar.idBahanBaku', 'left');

        $keluar = $this->db->get('bahanBakuKeluar')->result();
        echo '<div class="table-responsive mt-3">
        <table class="table table-hover table-centered mb-0">';
        echo '<thead>
        <tr>
            <th>Nama bahan Baku</th>
            <th>Jenis Cetak</th>
            <th>Jumlah</th>
            <th>Harga</th>
            <th>Ongkos</th>
            <th>Total Harga</th>
            <th></th>
        </tr>
    </thead>';
        echo '<tbody>';
        foreach ($keluar as $row) :
            echo    '<tr>
            <td>' . $row->namaBahanBaku . '</td>
            <td>' . $row->jenisCetak . '</td>
            <td>' . $row->jumlah . '</td>
            <td>' . number_format(floatval($row->hargaJual), 0, ',', '.') . '</td>
            <td>' . number_format(floatval($row->ongkos), 0, ',', '.') . '</td>
            <td>' . number_format(floatval($row->totalHarga), 0, ',', '.') . '</td>
            <td><a class=" hapus" href=" ' . base_url('admin/transaksicetak/ajaxdelete/' . $row->idBahanBakuKeluar) . '"><i class="mdi mdi-delete mr-1 text-muted"></i>Hapus</a></td>
            </tr>';
        endforeach;
        echo '</tbody>';
        echo '</table>
        </div>';
    }

    function ajaxharga()
    {
        if (isset($_GET['no'])) {
            $no = $_GET['no'];
            $this->db->select_sum('totalHarga', 'total');
            $this->db->where('noTransaksi', $no);
            $hasil = $this->db->get('bahanbakukeluar')->row();
            $data = [
                'th' => $hasil->total
            ];
            echo json_encode($data);
        }
    }

    function ajaxbahan()
    {
        $idBahan = $_GET['idBahan'];
        $this->db->where('idBahanBaku', $idBahan);
        $row = $this->db->get('bahanBaku')->row_array();

        $data = [
            'hargaBahan' => $row['hargaJual'],
        ];
        echo json_encode($data);
    }

    function ajaxdelete()
    {
        $id = $this->uri->segment(4);
        $this->db->where('idBahanBakuKeluar', $id);
        $this->db->delete('bahanbakukeluar');
        redirect('admin/' . $this->vn);
    }
}

/* End of file Rt.php */
