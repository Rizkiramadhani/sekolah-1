<?php


defined('BASEPATH') or exit('No direct script access allowed');

class stokbaju extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('stokbaju_m');
    }
    public $titles = 'Stok Baju';
    public $vn = 'stokbaju';

    public function index()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Data " . $this->titles;
        $data['data'] = $this->stokbaju_m->getAllData();

        $this->template->load('template', $this->vn . '/list', $data);
    }

    function add()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $this->template->load('template', $this->vn . '/add', $data);
    }

    function addAction()
    {
        $this->stokbaju_m->save();
        redirect('admin/' . $this->vn);
    }

    function edit()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $id = $this->uri->segment(4);
        $data['row'] = $this->stokbaju_m->getDataById($id);
        $this->template->load('template', $this->vn . '/edit', $data);
    }

    function editAction()
    {
        $id = $this->uri->segment(4);
        $this->stokbaju_m->update($id);
        redirect('admin/' . $this->vn);
    }

    function delete()
    {
        $id = $this->uri->segment(4);
        $this->stokbaju_m->delete($id);
        redirect('admin/' . $this->vn);
    }

    function ajaxbm()
    {
        if (isset($_GET['idBaju'])) {
            $idBaju = $_GET['idBaju'];

            $lengan = $_GET['lengan'];
            $data = $this->stokbaju_m->ajax($lengan);
            echo '<select name="idBaju" id="idBaju" class="form-control" required="">';
            if ($data) {
                foreach ($data as $row) {
                    ?>
                    <option <?php if ($idBaju == $row->idBaju) {
                                                    echo "selected";
                                                } ?> value="<?= $row->idBaju ?>"><?= $row->namaBaju ?></option>
<?php
                }
            } else {
                echo "<option>Data Baju Tidak Ada!</option>";
            }
            echo '</select>';
        } elseif (empty($_GET['idrt'])) {
            $lengan = $_GET['lengan'];
            $data = $this->stokbaju_m->ajax($lengan);
            echo '<select name="idBaju" id="idBaju" class="form-control" required="">';
            if ($data) {
                foreach ($data as $row) {
                    echo '<option value="' . $row->idBaju . '">' . $row->namaBaju . '</option>';
                }
            } else {
                echo "<option>Data Baju Tidak Ada!</option>";
            }
            echo '</select>';
        }
    }
}

/* End of file Rt.php */
