<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Pengabdian extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('pengabdian_m', 'primaryModel');
    }
    public $titles = 'Pengabdian Kepada Masyarakat';
    public $vn = 'pengabdian';

    public function index()
    {
        $data['title'] = $this->titles;
        $data['titlePage'] = "Data " . $this->titles;
        $this->template->load('home', $this->vn . '/add', $data);
    }

    function add()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $this->template->load('template', $this->vn . '/add', $data);
    }

    function add_action()
    {
        $this->primaryModel->insert();
        redirect('home/dashboard');
    }

    function edit()
    {
        $data['title'] = $this->titles;
        $data['pageTitle'] = "Tambah Data " . $this->titles;
        $id = $this->uri->segment(4);
        $data['row'] = $this->kategori_m->getDataById($id);
        $this->template->load('template', $this->vn . '/edit', $data);
    }

    function editAction()
    {
        $foto = $this->upload_foto();
        $id = $this->uri->segment(4);
        $this->kategori_m->update($id, $foto);
        redirect('datamaster/' . $this->vn);
    }

    function delete()
    {
        $id = $this->uri->segment(4);
        $this->kategori_m->delete($id);
        redirect('datamaster/' . $this->vn);
    }

    function upload_foto()
    {
        $config['upload_path']          = './upload/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 1024; // imb
        $this->load->library('upload', $config);
        // proses upload
        $this->upload->do_upload('gambar');
        $upload = $this->upload->data();
        return $upload['file_name'];
    }
}

/* End of file */
