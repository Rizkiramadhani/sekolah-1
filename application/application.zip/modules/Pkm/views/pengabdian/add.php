<?php
$option = array('1' => 'Mandiri', '2' => 'Internal', '3' => 'Join');
$opsi = array('1' => 'Kegiatan insidentil kurang dari 1 Bulan', '2' => 'Kegiatan non Incidental (1-6) bulan')
?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <form action="<?= base_url('pkm/pengabdian/add_action') ?>" method="post" class="needs-validation" novalidate>
                    <div class="form-group mb-3">
                        <label for="validationCustom01">Judul PKM</label>
                        <input type="text" class="form-control" name="judulPkm" id="validationCustom01" required>
                        <div class="invalid-feedback">
                            Harus diisi!
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">NIK Ketua</label>
                                <input type="text" class="form-control" name="nikKetua" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Nama Ketua</label>
                                <input type="text" class="form-control" name="namaKetua" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Jenis Pengabdian</label>
                                <?= form_dropdown('jenisPengabdian', $option, '', 'class="form-control"') ?>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Bidang Ilmu</label>
                                <input type="text" class="form-control" name="bidangIlmu" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Tanggal Pelaksanaan</label>
                                <input type="text" id="range-datepicker" name="tanggalPelaksanaan" class="form-control flatpickr-input active" readonly="readonly">
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Jenis</label>
                                <?= form_dropdown('jenis', $opsi, '', 'class="form-control"') ?>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Jumlah Mahasiswa Terlibat</label>
                                <input type="number" class="form-control" name="jumlahMahasiswa" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Jumlah Alumni Terlibat <span>(Jika ada)</span></label>
                                <input type="number" class="form-control" name="jumlahAlumni" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group mb-3">
                                <label for="validationCustom01">Jumlah Staf Terlibat selain anggota dosen <span>(Jika ada)</span></label>
                                <input type="text" class="form-control" name="jumlahStaf" id="validationCustom01" required>
                                <div class="invalid-feedback">
                                    Harus diisi!
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit">Simpan</button>
                </form>

            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
</div>