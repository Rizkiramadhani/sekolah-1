<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Sop_m extends CI_Model
{

    public $namaTable = 'sop_master';
    public $pk = 'idSop';

    function getAllData()
    {
        return $this->db->get($this->namaTable)->result();
    }

    function getDataById($Value)
    {
        $this->db->where($this->pk, $Value);
        $this->db->join('baju', 'baju.idBaju = bajumasuk.idBaju', 'left');
        return $this->db->get($this->namaTable)->row();
    }

    function save()
    {
        $tgl = date('Y-m-d', strtotime($this->input->post('tanggalMasuk')));
        $object = [
            'idBaju' => $this->input->post('idBaju'),
            'tanggalMasuk' => $tgl,
            'stok' => str_replace('.', '', $this->input->post('stok')),
            'harga' => str_replace('.', '', $this->input->post('harga')),
        ];
        $this->db->insert($this->namaTable, $object);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Disimpan</div>');
    }

    function update($Value)
    {
        $tgl = date('Y-m-d', strtotime($this->input->post('tanggalMasuk')));
        $object = [
            'idBaju' => $this->input->post('idBaju'),
            'tanggalMasuk' => $tgl,
            'stok' => str_replace('.', '', $this->input->post('stok')),
            'harga' => str_replace('.', '', $this->input->post('harga')),
        ];

        $this->db->where($this->pk, $Value);
        $this->db->update($this->namaTable, $object);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Di Rubah</div>');
    }

    function delete($Value)
    {
        $this->db->where($this->pk, $Value);
        $this->db->delete($this->namaTable);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Berhasil Di Hapus</div>');
    }

    function ajax($Value)
    {
        $this->db->where('lenganPanjang', $Value);
        $result = $this->db->get('baju')->result();
        return $result;
    }
}

/* End of file */
